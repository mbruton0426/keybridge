from collections import defaultdict
import random
import string
import pickle
from importlib import resources
import warnings


class ChronoFidelius:
    """
    A class designed to facilitate the encryption and manipulation of plaintext
    with optional error injection and formatting using historical frequencies and methods.
    """

    def __init__(self, plaintext,
                 set_seed: int = None,
                 include_errors: bool = False,
                 error_type: str = None,
                 error_frequency: float = 0.05,
                 include_spacing: bool = False,
                 max_length: int = 200,
                 set_punctuation: str = string.punctuation,
                 set_case: str = "upper",
                 cancel_marker: str = "\u2190",
                 cancel_span_markers: tuple = ("\u27e6", "\u27e7")):
        """
            Initializes the ChronoFidelius class with plaintext and optional configurations.

            Parameters:
            - plaintext (str or list of str): The input plaintext to be processed.
            - set_seed (int, optional): A seed value for reproducibility of random operations. Default is None.
            - include_errors (bool, optional): If True, introduces errors (e.g., additions, deletions, doubles) into
            the plaintext. Default is False.
            - error_type (str, optional): Specifies the type of error to introduce. Valid options are:
                - "additions": Adds random characters.
                - "deletions": Removes characters.
                - "doubles": Doubles characters.
                - "cancelled": Adds a wrong character followed by `cancel_marker`, as a clerk who wrote a wrong
                  symbol and then a sign cancelling it.
                - "cancelled_span": Adds 1-3 wrong characters wrapped in `cancel_span_markers` (start, end).
                - "all": Randomly selects between "additions", "deletions", or "doubles".
                A list or tuple of the types above is also accepted; one is chosen at random for each error.
                Must be set if `include_errors` is True. Default is None.
            - error_frequency (float, optional): Frequency of errors in the plaintext (0–1). For example, 0.05
            introduces errors to 5% of the text. Default is 0.05.
            - include_spacing (bool, optional): If True, retains spaces and line breaks during formatting. Default is
            False.
            - max_length (int, optional): Maximum length of the formatted plaintext or chunks. Default is 200.
            - set_punctuation (str, optional): Specifies the set of punctuation characters to remove. Default is
            string.punctuation.
            - set_case (str, optional): Specifies case for plaintext strings. Default is upper. Valid options are:
                - "upper": Uppercase all characters
                - "lower": Lowercase all characters
                - "no_change": Make no changes to case
            - cancel_marker (str, optional): The character written after a wrong character for "cancelled" errors.
            Map it to your cancel-sign codes in `encryption_dict`. Default is "\u2190" (←).
            - cancel_span_markers (tuple of 2 str, optional): The start and end characters around a "cancelled_span".
            Default is ("\u27e6", "\u27e7") (⟦ ⟧).

            Raises:
            - TypeError: If `plaintext` is not a string or a list of strings.
            - ValueError: If `include_errors` is True but `error_type` is not specified or invalid.
            - ValueError: If `error_frequency` exceeds 1.
        """

        self.set_case = set_case

        if isinstance(plaintext, str):
            self.plaintext = self._set_case(plaintext)
        elif isinstance(plaintext, list):
            self.plaintext = [self._set_case(text) for text in plaintext]
        else:
            raise TypeError(f"Invalid plaintext type. Valid types: str, list")

        self.valid_lang_codes = ["cz", "nl", "en", "fr", "de", "el", "hu", "is",
                                 "it", "la", "pl", "ru", "sl", "es", "sv"]
        self.valid_languages = ["Czech (cz)", "Dutch (nl)", "English (en)", "French (fr)", "German (de)", "Greek (el)",
                                "Hungarian (hu)", "Icelandic (is)", "Italian (it)", "Latin (la)", "Polish (pl)",
                                "Russian (ru)", "Slovene (sl)", "Spanish (es)", "Swedish (sv)"]

        self.seed = set_seed
        self.punctuation = set_punctuation
        self.max_length = max_length
        self.pt_ct_dict = defaultdict(dict)  # holds all plaintext and ciphertext

        self.error_types = ["additions", "deletions", "doubles"]  # what "all" chooses from
        self.cancel_marker = cancel_marker
        self.cancel_span_markers = tuple(cancel_span_markers)
        self.errors = include_errors
        check_error_types = self.error_types + ["cancelled", "cancelled_span", "all"]

        if include_errors:
            if error_type is None:
                raise ValueError(f"If include_errors must set error_type.")
            chosen = list(error_type) if isinstance(error_type, (list, tuple)) else [error_type]
            if not chosen or any(e not in check_error_types for e in chosen):
                raise ValueError(f"Invalid error_type. Valid options: {check_error_types} (or a list of them)")
            if error_frequency > 1:
                raise ValueError(f"Invalid error_frequency. {error_frequency} must \
                be less than 1.")
            else:
                self._format_plaintext(plaintext=self.plaintext,
                                       include_spacing=include_spacing,
                                       error_type=error_type,
                                       error_frequency=error_frequency)
        else:
            self._format_plaintext(plaintext=self.plaintext,
                                   include_spacing=include_spacing)

    def encrypt_homophonic(self, key_type: str = "even",
                           encryption_dict: dict = None,
                           lang_code: str = None,
                           set_frequencies: dict = None,
                           set_alphabet: str = None,  # string.ascii_uppercase,
                           freq_year: str = None,
                           ct_as_int: bool = True,
                           mix_code=None,
                           null_codes: list = None,
                           null_frequency: float = 0.05,
                           multi_char_frequency: float = 1.0,
                           unmatched: str = "keep"):
        """
            Encrypts plaintext using a homophonic cipher.

            Parameters:
            - key_type (str): The type of encryption key ("even", "uneven", or "both"). Default is "even".
            - encryption_dict (dict): Optional pre-defined encryption dictionary.
            - lang_code (str): Language code for frequency analysis.
            - set_frequencies (dict): Custom frequency mappings for uneven key generation.
            - set_alphabet (str): Alphabet to use for even key generation.
            - freq_year (str): Year to use for historical frequency data.
            - ct_as_int (bool): Whether to represent ciphertext as string integers. Default is True.
            - mix_code: Defines whether to mix different length integers as codes.
            Included digit lengths entered as a tuple (1 ,2), (2, 3), (2, 3, 4), etc...
            - null_codes (list, optional): Codes that stand for nothing (nulls). When given, a null code is inserted
            before a plaintext position with probability `null_frequency`. Default is None (no nulls).
            - null_frequency (float): Share of positions that get a null before them (0-1). Default is 0.05.
            - multi_char_frequency (float): Share of the time a matching multi-character entry (syllable, word) is
            used; otherwise the text is spelled out with shorter entries. Default is 1.0 (always, as before).
            - unmatched (str): What to do with characters that have no entry: "keep" copies them into the
            ciphertext unchanged (as before), "drop" leaves them out and counts them in `self.unmatched`.

            Each document also gets "segments": a list of [plaintext piece, code] pairs, in order (the piece is
            None for an inserted null), so the ciphertext can be lined up with the plaintext.

            Raises:
            - ValueError: If `key_type` or `unmatched` is invalid, or a frequency is outside 0-1.

        """

        self.ct_as_int = ct_as_int

        self.mix_code = mix_code

        if unmatched not in ("keep", "drop"):
            raise ValueError('unmatched must be "keep" or "drop".')
        for name, value in (("null_frequency", null_frequency), ("multi_char_frequency", multi_char_frequency)):
            if not 0 <= value <= 1:
                raise ValueError(f"{name} must be between 0 and 1.")
        self.null_codes = list(null_codes) if null_codes else []
        self.null_frequency = null_frequency
        self.multi_char_frequency = multi_char_frequency
        self.unmatched_mode = unmatched
        self.unmatched = defaultdict(int)

        valid_digit_lengths = {1, 2, 3, 4}
        key_types = ["even", "uneven", "both"]

        if self.mix_code:
            if not isinstance(self.mix_code, tuple) or not all(d in valid_digit_lengths for d in self.mix_code):
                raise ValueError(f"mix_code must be a tuple of digit lengths from {valid_digit_lengths}, e.g. (2, 3).")
            if len(set(self.mix_code)) < 2:
                raise ValueError("mix_code must contain at least two distinct digit lengths.")

        if encryption_dict:
            self.alphabet = "".join(sorted(list(set("".join(encryption_dict.keys())))))
            self.key = {k: encryption_dict[k] for k in sorted(encryption_dict, key=len, reverse=True)}
            all_plaintexts = [key for key in self.pt_ct_dict.keys() if not key.startswith(("key", "ciphertext"))]

            for each_doc in all_plaintexts:
                doc = self.pt_ct_dict[each_doc]["plaintext"] if self.errors == False else self.pt_ct_dict[each_doc][
                    "plaintext_errors_included"]
                chars_in_doc = sorted(set(doc))

                ct, doc_specific_key_dict = self._encryption_homophonic(doc, self.key)

                self.pt_ct_dict[each_doc]["ciphertext"] = ct
                self.pt_ct_dict[each_doc]["key"] = doc_specific_key_dict
                self.pt_ct_dict[each_doc]["segments"] = self.last_segments

        else:  # no encryption_dict

            if not set_alphabet and not lang_code:
                set_alphabet = string.ascii_uppercase
            elif set_alphabet:
                set_alphabet = set_alphabet
            else:  # not set_alphabet and lang_code
                char_freqs = self._load_char_freqs(lang_code)

                if not freq_year:
                    set_alphabet = self._set_case("".join(char_freqs['all'].keys()), to_join=True)
                else:
                    try:
                        set_alphabet = self._set_case("".join(char_freqs[freq_year].keys()), to_join=True)
                    except:
                        raise ValueError(
                            f"Invalid year_range: {freq_year} not supported. Valid options for language {lang_code} are: {char_freqs.keys()}"
                        )

            random.seed(self.seed)

            if key_type == "uneven":
                self._uneven_key_type(set_frequencies, freq_year, lang_code)
            elif key_type == "even":
                self._even_key_type(set_alphabet)
            elif key_type == "both":
                self._uneven_key_type(set_frequencies, freq_year, lang_code)
                self._even_key_type(set_alphabet)
            else:
                raise ValueError(f"Invalid key_type. Valid options: {key_types}")

    def _format_plaintext(self, plaintext, include_spacing: bool,
                          error_type: str = None, error_frequency: float = None):
        """
            Formats the plaintext by cleaning, splitting, and optionally introducing errors.

            Parameters:
            - plaintext (str or list of str): The input plaintext to be formatted.
            - include_spacing (bool): If True, retains spaces and line breaks during formatting.
            - error_type (str or list, optional): The type(s) of error to introduce: "additions", "deletions",
                "doubles", "cancelled", "cancelled_span", or "all" (additions, deletions or doubles). Default is None.
            - error_frequency (float, optional): Frequency of errors in the plaintext (0–1). For example, 0.05
            introduces errors to 5% of the text. Default is None.
            - set_case (str, optional): Specifies case for plaintext strings (e.g., upper, lower, no_change). Default
            is upper.

            Sets:
            - self.formatted_plaintext: The cleaned and processed plaintext.
            - self.pt_ct_dict: A dictionary where:
                - Each key represents a chunk index.
                - Each value contains:
                    - "plaintext": The corresponding chunk of plaintext.
                    - "plaintext_errors_included": The chunk including errors as characters (if applicable).
                    - "plaintext_errors_hashed": The chunk including errors as '#' for insertions and '&' for
                    deletions (if applicable); for cancelled errors the wrong characters are '#' and the cancel
                    markers are kept.

            Raises:
            - TypeError: If `plaintext` is not a string or list of strings.
        """

        random.seed(self.seed)
        unwanted_chars = self.punctuation + ("\n\t" if include_spacing else " \n\t")

        if isinstance(plaintext, str):
            clean_plaintext = "".join([char for char in plaintext if char not in unwanted_chars])
            split_formatted_plaintext = self._chunk_plaintext(
                text_string=clean_plaintext, max_length=self.max_length)

        elif isinstance(plaintext, list):
            clean_plaintext = [
                "".join([char for char in text if char not in unwanted_chars])
                for text in plaintext
            ]

            split_formatted_plaintext = [
                chunk
                for text in clean_plaintext
                for chunk in self._chunk_plaintext(text_string=text, max_length=self.max_length)
            ]

        self.formatted_plaintext = clean_plaintext

        for i, text_chunk in enumerate(split_formatted_plaintext):
            self.pt_ct_dict[str(i)]["plaintext"] = text_chunk

            if not error_frequency:
                self.pt_ct_dict[str(i)]["plaintext_errors_hashed"] = None
                self.pt_ct_dict[str(i)]["plaintext_errors_included"] = None

            else:
                pt_len = len(text_chunk)
                if pt_len == 0:
                    self.pt_ct_dict[str(i)]["plaintext_errors_hashed"] = ""
                    self.pt_ct_dict[str(i)]["plaintext_errors_included"] = ""
                    continue
                total_errors = max(1, int(pt_len * error_frequency))
                sorted_indexes = set(random.sample(range(pt_len), min(total_errors, pt_len)))
                choices = list(error_type) if isinstance(error_type, (list, tuple)) else [error_type]

                gold_pt_errors = ""
                gold_pt_errors_hashed = ""
                for j, char in enumerate(text_chunk):
                    if j in sorted_indexes:
                        error_choice = random.choice(choices)
                        if error_choice == "all":
                            error_choice = random.choice(self.error_types)
                        changed = self._make_error_choice(char, error_choice, pool=text_chunk)
                        gold_pt_errors += changed

                        if error_choice == "additions" or error_choice == "doubles":
                            gold_pt_errors_hashed += char + "#"
                        elif error_choice in ("cancelled", "cancelled_span"):
                            # wrong characters shown as '#', the cancel signs kept, then the right character
                            gold_pt_errors_hashed += "".join(
                                c if c in (self.cancel_marker,) + self.cancel_span_markers else "#" for c in
                                changed[:-1]
                            ) + char
                        else:
                            gold_pt_errors_hashed += "&"
                    else:
                        gold_pt_errors += char
                        gold_pt_errors_hashed += char

                self.pt_ct_dict[str(i)]["plaintext_errors_hashed"] = gold_pt_errors_hashed
                self.pt_ct_dict[str(i)]["plaintext_errors_included"] = gold_pt_errors

    def _set_case(self, to_set, to_join=False):
        if self.set_case == "upper":
            cases_item = to_set.upper()
        elif self.set_case == "lower":
            cases_item = to_set.lower()
        elif self.set_case == "no_change" and to_join == True:
            cases_item = to_set.upper() + to_set.lower()
        elif self.set_case == "no_change" and to_join == False:
            cases_item = to_set
        else:
            raise ValueError(f"Invalid case option. Valid options: upper, lower, no_change")

        return cases_item

    def _load_char_freqs(self, lang_code):
        if lang_code not in self.valid_lang_codes:
            raise ValueError(
                f"Invalid lang_code: '{lang_code}' is not supported. Valid options are: {self.valid_languages}")

        filepath = resources.files('chronofidelius.char_freqs').joinpath(f"{lang_code}_char_freqs_dict.pkl")

        with filepath.open("rb") as f:
            return pickle.load(f)

    def _link_keys_to_plaintext(self, key_prefix: str):
        all_key_dicts = [key for key in self.pt_ct_dict.keys() if key.startswith(key_prefix)]
        all_plaintexts = [key for key in self.pt_ct_dict.keys() if not key.startswith(("key", "ciphertext"))]

        for each_doc in all_plaintexts:
            doc = self.pt_ct_dict[each_doc]["plaintext"] if self.errors == False else self.pt_ct_dict[each_doc][
                "plaintext_errors_included"]
            chars_in_doc = sorted(set(doc))

            for key_dict in all_key_dicts:
                current_dict = self.pt_ct_dict[key_dict]
                ct_title = f"ciphertext{key_dict[3:]}"
                ct, doc_specific_key_dict = self._encryption_homophonic(doc, current_dict)

                self.pt_ct_dict[each_doc][ct_title] = ct
                self.pt_ct_dict[each_doc][key_dict] = doc_specific_key_dict

    def _sample_by_digits(self, digit_count: int, total: int):
        if total > 10 ** digit_count:
            total = 10 ** digit_count
        return random.sample([f"{i:0{digit_count}}" for i in range(10 ** digit_count)], total)

    def _make_error_choice(self, plaintext_char: str, error_type: str, pool: str = None):
        """
        Modifies a plaintext character based on the specified type of error.

        Parameters:
        - plaintext_char (str): The character from the plaintext to be modified.
        - error_type (str): The type of error to introduce. Valid options are
                            "additions", "deletions", "doubles", "cancelled" and "cancelled_span".
                            Added (wrong) characters are a random choice of a character from `pool`.
        - pool (str, optional): Characters to draw added characters from (the current chunk). Defaults to the
                            whole formatted plaintext.

        Returns:
        - str: The modified plaintext character after introducing the specified error.
        """
        # (no reseeding here: reseeding on every call made every 'random' character the same)
        if pool is None:
            pool = self.formatted_plaintext if isinstance(self.formatted_plaintext, str) else "".join(
                self.formatted_plaintext)
        pool = pool or plaintext_char

        def wrong_char():
            others = [c for c in pool if
                      c != plaintext_char and c not in (self.cancel_marker,) + self.cancel_span_markers]
            return random.choice(others) if others else random.choice(pool)

        if error_type == "additions":
            return plaintext_char + random.choice(pool)
        elif error_type == "deletions":
            return ""
        elif error_type == "doubles":
            return plaintext_char + plaintext_char
        elif error_type == "cancelled":
            return wrong_char() + self.cancel_marker + plaintext_char
        elif error_type == "cancelled_span":
            start, end = self.cancel_span_markers
            return start + "".join(wrong_char() for _ in range(random.randint(1, 3))) + end + plaintext_char
        else:
            raise ValueError(f"{error_type} not valid.")

    def _chunk_plaintext(self, text_string: str, max_length: int):
        """
        Divides a text string into chunks of a specified maximum length.

        Parameters:
        - text_string (str): The string to be chunked.
        - max_length (int): The maximum length of each chunk. It must be a
                            positive integer.

        Returns:
        - list of str: A list containing the chunked substrings. If the original
          string is empty or the max_length is greater than the string length,
          the list will contain the original string as the only element. If
          max_length is less than or equal to zero, the list will be empty.
        """

        return [text_string[i:i + max_length] for i in
                range(0, len(text_string), max_length)]

    def _uneven_key_type(self, set_frequencies: dict = None, freq_year: str = None, lang_code: str = None):
        """
        Configures uneven key types for homophonic encryption.

        Parameters:
        - set_frequencies (dict, optional): A custom frequency dictionary mapping characters to their frequencies.
        - freq_year (str, optional): The year for which unigram frequencies are used.
        - lang_code (str, optional): The language code to select predefined unigram frequencies.

        Sets:
        - self.alphabet (str): The alphabet used for encryption, derived from the frequency dictionary.
        - self.frequency_dict (dict): The dictionary containing character frequencies.

        Raises:
        - ValueError: If both `set_frequencies` and `freq_year` are provided.
        - ValueError: If neither `set_frequencies` nor `freq_year` is provided.
        - ValueError: If `lang_code` is invalid or not supported.
        """

        if set_frequencies and freq_year:
            raise ValueError("Cannot declare both set_frequencies and freq_year.")

        if set_frequencies:
            self.alphabet = self._set_case("".join(set_frequencies.keys()), to_join=True)
            self.frequency_dict = set_frequencies

        elif freq_year:
            try:
                char_freqs = self._load_char_freqs(lang_code)
                self.frequency_dict = char_freqs[freq_year]
            except:
                raise ValueError(
                    f"Invalid year_range: {freq_year} not supported. Valid options for language {lang_code} are: {char_freqs.keys()}"
                )

            self.alphabet = self._set_case("".join(self.frequency_dict.keys()), to_join=True)

        else:
            raise ValueError("Must provide either set_frequencies or freq_year for uneven key_type.")

        self._uneven_splits_homophonic()

    def _even_key_type(self, set_alphabet):
        """
            Configures even key types for homophonic encryption.

            Parameters:
            - set_alphabet (str): The alphabet to use for even key generation.

            Sets:
            - self.alphabet (str): The alphabet used for encryption.

        """
        self.alphabet = set_alphabet
        self._even_splits_homophonic()

    def _even_splits_homophonic(self):
        """
            Generates encryption dictionaries for even key types and links them to plaintexts.

            This method creates encryption dictionaries for keys of varying lengths (2, 3, and 4),
            with multiple options for each length. The encryption dictionaries are then linked
            to the plaintext chunks and ciphertexts based on the characters present in each document.

            Sets:
            - Updates `self.pt_ct_dict` to include:
                - Ciphertexts for each plaintext chunk.
                - Encryption dictionaries specific to each document.

            Raises:
            - ValueError: If `self.alphabet` is not set or is empty.
        """

        if not self.alphabet:
            raise ValueError("Alphabet is not set or is empty. Cannot generate encryption dictionaries.")

        random.seed(self.seed)

        key_lengths = {
            2: {"bottom_n": 10, "factor": 3, "extra": 5, "options": 3},
            3: {"bottom_n": 100, "factor": 5, "extra": 10, "options": 5},
            4: {"bottom_n": 1000, "factor": 5, "extra": 15, "options": 5},
        }

        if self.mix_code:
            dict_category = f"key_even_len{'_'.join(map(str, self.mix_code))}"

            for option in range(1, 6):
                category_name = f"{dict_category}_{option}opt"
                self._set_encryption_dict_even(None, None, option, category_name)

        else:
            for key_len, params in key_lengths.items():
                total_numbers_needed = len(self.alphabet) * params["factor"] + params["extra"]
                dict_category = f"key_even_len_{key_len}"

                for option in range(1, params["options"] + 1):
                    category_name = f"{dict_category}_{option}opt"
                    try:
                        self._set_encryption_dict_even(
                            params["bottom_n"], total_numbers_needed, options=option, category_name=category_name
                        )
                    except:
                        continue

        self._link_keys_to_plaintext("key_even")

    def _uneven_splits_homophonic(self):
        """
            Generates encryption dictionaries for uneven key types and links them to plaintexts.

            This method dynamically calculates frequency distributions for uneven key types,
            generates encryption dictionaries for keys of varying lengths (2, 3, and 4), and
            links the dictionaries and corresponding ciphertexts to the plaintexts.

            Sets:
            - Updates `self.pt_ct_dict` to include:
                - Ciphertexts for each plaintext chunk.
                - Encryption dictionaries specific to each document.

            Raises:
            - ValueError: If `self.frequency_dict` is not set or is empty.

        """
        if not self.frequency_dict:
            raise ValueError("Frequency dictionary is not set or is empty. \
            Cannot generate uneven encryption dictionaries.")

        random.seed(self.seed)

        avg = sum(self.frequency_dict.values()) / len(self.frequency_dict.values())
        sort_freq = sorted(set(self.frequency_dict.values()))
        less_idx, more_idx = self._set_index(sort_freq, avg)
        options_dict_freq = self._frequency_to_options_dict(less_idx, more_idx, sort_freq)
        total_numbers_needed = sum(options_dict_freq.values()) + 5

        key_lengths = {
            2: 10,
            3: 100,
            4: 1000,
        }

        for key_len, params in key_lengths.items():
            dict_category = f"key_uneven_len_{key_len}_uneven"
            try:
                self._set_encryption_dict_uneven(
                    params, total_numbers_needed, options_dict_freq, dict_category
                )
            except:
                continue

        self._link_keys_to_plaintext("key_uneven")

    def _set_encryption_dict_even(self,
                                  start: int,
                                  total: int,
                                  options: int,
                                  category_name: str):
        """
        Creates an encryption dictionary for even key types.

        This method assigns random unique numbers to each character in `self.alphabet` for encryption.
        Each character is assigned a specified number of random numbers (`options`).

        Parameters:
        - start (int): The starting range of random numbers.
        - stop (int): The ending range of random numbers (exclusive).
        - total (int): The total number of random numbers required.
        - options (int): The number of random numbers assigned to each character.
        - category_name (str): The name under which the dictionary is stored in `self.pt_ct_dict`.

        Sets:
        - self.pt_ct_dict[category_name]: A dictionary mapping each character in `self.alphabet`
          to a list of random unique numbers.
        """

        random.seed(self.seed)
        buffer = 10

        if self.mix_code:
            options_per_char = [options] * len(self.alphabet)
            total = len(self.alphabet) * options
            per_pool = total // len(self.mix_code) + buffer

            random_unique_numbers = []
            for digits in self.mix_code:
                random_unique_numbers += self._sample_by_digits(digits, per_pool)

            present_lengths = {len(code) for code in random_unique_numbers}
            for digits in self.mix_code:
                if digits not in present_lengths:
                    random_unique_numbers += self._sample_by_digits(digits, buffer)  # changed from append

            pool_set = set(random_unique_numbers)
            prev_size = -1

            while len(pool_set) < total:
                if len(pool_set) == prev_size:
                    break
                prev_size = len(pool_set)

                for digits in self.mix_code:
                    pool_set.update(self._sample_by_digits(digits, total + buffer))

            random_unique_numbers = list(pool_set)
            random.shuffle(random_unique_numbers)

        else:
            digit_map = {10: 2, 100: 3, 1000: 4}
            options_per_char = [options] * len(self.alphabet)
            random_unique_numbers = self._sample_by_digits(digit_map[start], total + buffer)

        random_unique_numbers = list(set(random_unique_numbers))
        available = len(random_unique_numbers)
        scaled = self._scale_options(options_per_char, available)

        if scaled != options_per_char:
            warnings.warn(
                f"Pool has {available} unique codes but {sum(options_per_char)} were "
                f"requested. Option counts have been reduced proportionally; all "
                f"characters are guaranteed at least 1 code.",
                RuntimeWarning
            )

        starting_index = 0
        encryption_dict = {}

        for char, count in zip(self.alphabet, scaled):
            encryption_dict[char] = random_unique_numbers[starting_index:starting_index + count]
            starting_index += count

        self.pt_ct_dict[category_name] = encryption_dict

    def _set_encryption_dict_uneven(self,
                                    start: int,
                                    total: int,
                                    options: dict,
                                    category_name: str):
        """
            Creates an encryption dictionary for uneven key types.

            This method assigns a varying number of random unique numbers to each character in
            `self.alphabet` based on its frequency, as specified in `self.frequency_dict`.

            Parameters:
            - start (int): The starting range of random numbers.
            - total (int): The total number of random numbers required.
            - options (dict): A mapping of frequencies to the number of random numbers to assign.
            - category_name (str): The name under which the dictionary is stored in `self.pt_ct_dict`.

            Sets:
            - self.pt_ct_dict[category_name]: A dictionary mapping each character in `self.alphabet`
              to a list of random unique numbers.
        """

        random.seed(self.seed)

        options_per_char = []
        buffer = 10

        for char in self.alphabet:
            freq = self.frequency_dict.get(char.lower()) or self.frequency_dict.get(char.upper())

            if freq is None:
                raise KeyError(f"Frequency for character '{char}' not found in frequency dictionary.")

            if freq not in options:
                raise KeyError(f"Frequency '{freq}' not found in options dictionary.")

            options_per_char.append(options[freq])

        total_requested = sum(options_per_char)

        if self.mix_code:
            per_pool = total_requested // len(self.mix_code) + buffer

            random_unique_numbers = []
            for digits in self.mix_code:
                random_unique_numbers += self._sample_by_digits(digits, per_pool)

            present_lengths = {len(code) for code in random_unique_numbers}
            for digits in self.mix_code:
                if digits not in present_lengths:
                    random_unique_numbers += self._sample_by_digits(digits, buffer)

            pool_set = set(random_unique_numbers)
            prev_size = -1

            while len(pool_set) < total_requested:
                if len(pool_set) == prev_size:
                    break
                prev_size = len(pool_set)

                for digits in self.mix_code:
                    pool_set.update(self._sample_by_digits(digits, total + buffer))

            random_unique_numbers = list(pool_set)
            random.shuffle(random_unique_numbers)

        else:
            digit_map = {10: 2, 100: 3, 1000: 4}
            random_unique_numbers = self._sample_by_digits(digit_map[start], total + buffer)

        random_unique_numbers = list(set(random_unique_numbers))
        available = len(random_unique_numbers)
        scaled = self._scale_options(options_per_char, available)

        if scaled != options_per_char:
            warnings.warn(
                f"Pool has {available} unique codes but {total_requested} were "
                f"requested. Option counts have been reduced proportionally; all "
                f"characters are guaranteed at least 1 code.",
                RuntimeWarning
            )

        starting_index = 0
        encryption_dict = {}

        for char, count in zip(self.alphabet, scaled):
            encryption_dict[char] = random_unique_numbers[starting_index:starting_index + count]
            starting_index += count

        self.pt_ct_dict[category_name] = encryption_dict

    def _scale_options(self, options_per_char: list, available: int) -> list:
        """
        Scales down a list of per-character option counts so their sum fits within
        `available`, reducing the highest counts first.

        Parameters:
        - options_per_char (list of int): requested number of codes per character,
          in alphabet order.
        - available (int): total number of unique codes in the pool.

        Returns:
        - list of int: adjusted counts guaranteed to sum to <= available,
          with every value >= 1.
        """
        counts = options_per_char[:]

        while sum(counts) > available:
            max_val = max(counts)
            if max_val == 1:
                warnings.warn(
                    "Pool is smaller than the alphabet size. "
                    "Some characters may share codes or receive only 1 code.",
                    RuntimeWarning
                )
                break
            counts = [c - 1 if c == max_val else c for c in counts]

        return counts

    def _set_index(self, sorted_frequencies: list, average_frequency: float) -> tuple:
        """
        Determines indices for splitting the list of sorted frequencies into categories.

        The "under" group (frequencies below or equal to the average) is split into two parts,
        while the "over" group (frequencies above the average) is split into three parts.

        Parameters:
        - sorted_frequencies (list of float): A list of frequencies sorted in ascending order.
        - average_frequency (float): The average frequency to divide the groups.

        Returns:
        - tuple: A tuple containing two integers:
            - The first integer represents the division point (index) in the "under" group.
            - The second integer represents the division point in the "over" group.

        """

        total_under = sum(1 for freq in sorted_frequencies if freq <= average_frequency)
        total_over = len(sorted_frequencies) - total_under

        under_option_split = round(total_under / 2)
        over_option_split = round(total_over / 3)

        return under_option_split, over_option_split

    def _frequency_to_options_dict(self, low_freq_split_index,
                                   high_freq_split_index, sorted_frequencies):
        """
        Creates a dictionary mapping each unique frequency to a specified number of
        options based on its position. Frequencies are categorized into five groups.

        Parameters:
        - low_freq_split_index (int): The index used to determine the split point
                                      for lower frequencies.
        - high_freq_split_index (int): The index used to determine the split point
                                       for higher frequencies.
        - sorted_frequencies (list of int/float): A list of unique frequencies
                                                  sorted in ascending order.

        Returns:
        - options_dict: A dictionary where each key is a unique frequency from
                        `sorted_frequencies` and each value is an integer from 1 to
                        5, representing the number of options allocated to that
                        frequency category.

        """

        options_dictionary = dict()

        for i, freq in enumerate(sorted_frequencies):
            if i < low_freq_split_index:
                options_dictionary[freq] = 1
            elif i < (low_freq_split_index * 2):
                options_dictionary[freq] = 2
            elif i < ((low_freq_split_index * 2) + high_freq_split_index):
                options_dictionary[freq] = 3
            elif i < ((low_freq_split_index * 2) + (high_freq_split_index * 2)):
                options_dictionary[freq] = 4
            else:
                options_dictionary[freq] = 5

        return options_dictionary

    def _encryption_homophonic(self, plaintext: str, encryption_dictionary: dict):
        """
        Encrypts a given plaintext using a homophonic substitution cipher.

        The plaintext is read from left to right; at each position the longest matching entry of the
        encryption dictionary is used (multi-character entries only `multi_char_frequency` of the time), and
        replaced by a random choice from its codes. Nulls are inserted if `null_codes` was given. Characters
        not found in the dictionary are kept unchanged or dropped (see `unmatched` in encrypt_homophonic).

        Parameters:
        - plaintext (str): The message to be encrypted.
        - encryption_dictionary (dict): A dictionary where each key is a plaintext
                                         character (or sequence) and each value is a list of encryption
                                         options for that character (a single value is treated as one code).

        Returns:
        - str or list: The encrypted message. If `self.ct_as_int` is False, the message is
                       returned as a string with encrypted characters separated by
                       "_". If `self.ct_as_int` is True, the message is returned
                       as a list of string integers.
        - dict: the codes actually used for each entry in this document.
        Also sets `self.last_segments`: [plaintext piece, code] pairs in order (piece None for a null).
        """
        multi_rate = getattr(self, "multi_char_frequency", 1.0)
        null_codes = getattr(self, "null_codes", [])
        null_rate = getattr(self, "null_frequency", 0.0)
        drop = getattr(self, "unmatched_mode", "keep") == "drop"
        if not hasattr(self, "unmatched"):
            self.unmatched = defaultdict(int)

        # entries grouped by first character, longest first (much faster than trying every entry)
        by_first = defaultdict(list)
        for k in sorted(encryption_dictionary, key=len, reverse=True):
            v = encryption_dictionary[k]
            if isinstance(v, (list, tuple, set)):
                v = list(v)
            else:
                v = [str(v) if isinstance(v, int) else v]  # a single code, e.g. "12" or 12
            if k and v:
                by_first[k[0]].append((k, v))

        ciphertext, segments = [], []
        doc_key_dict = defaultdict(set)
        i = 0
        n = len(plaintext)

        while i < n:
            if null_codes and random.random() < null_rate:
                code = random.choice(null_codes)
                ciphertext.append(code)
                segments.append([None, code])
            match = None
            for k, v in by_first.get(plaintext[i], ()):
                if plaintext.startswith(k, i):
                    if len(k) > 1 and multi_rate < 1 and random.random() >= multi_rate:
                        continue  # spell this one out with shorter entries
                    match = (k, v)
                    break
            if match:
                k, v = match
                ct_choice = random.choice(v)
                ciphertext.append(ct_choice)
                segments.append([k, ct_choice])
                doc_key_dict[k].add(ct_choice)
                i += len(k)
            else:
                if drop:
                    self.unmatched[plaintext[i]] += 1
                else:
                    ciphertext.append(plaintext[i])
                    segments.append([plaintext[i], plaintext[i]])
                i += 1

        self.last_segments = segments
        doc_key_dict = {k: sorted(list(doc_key_dict[k])) for k in sorted(doc_key_dict, key=len, reverse=True)}

        return ciphertext if self.ct_as_int else "_".join(map(str, ciphertext)), doc_key_dict

    # if __name__ == "__main__":
    """
    obj = ChronoFidelius("aabbffssaabababbas", include_errors=True, error_type="all", # set_seed=9,
                         set_case="no_change", error_frequency=0.5)
    d = {
        "a": [1, 8, 7],
        "aa": 2,
        "b": 3,
        "bb": 4,
        "ss": 5,
        "x": 9
    }

    obj.encrypt_homophonic(encryption_dict=d) # , set_frequencies={"h": 0.5, "e": 0.1, "l" : 0.4})
    print(obj.alphabet)
    print(obj.pt_ct_dict)
"""


"""
    e_or_une = "even"
    obj = ChronoFidelius("aabbffssaabababbas", include_errors=True, error_type="all", # set_seed=9,
                         set_case="no_change", error_frequency=0.5)

    obj.encrypt_homophonic(lang_code="sv", key_type=e_or_une, mix_code=(2,3))
    print(obj.alphabet)

    print(obj.pt_ct_dict["0"])
    pt = obj.pt_ct_dict["0"]["plaintext"]
    pt_err = obj.pt_ct_dict["0"]["plaintext_errors_included"]
    pt_hash = obj.pt_ct_dict["0"]["plaintext_errors_hashed"]
    if e_or_une == "even" or e_or_une == "both":
        ct = obj.pt_ct_dict["0"]["ciphertext_even_len_4_5opt"]
    elif e_or_une == "uneven":
        ct = obj.pt_ct_dict["0"]["ciphertext_uneven_len_4_uneven"]

    print(f"{len(pt)=}, {len(pt_err)=}, {len(pt_hash)=}, {len(ct)=}")
"""